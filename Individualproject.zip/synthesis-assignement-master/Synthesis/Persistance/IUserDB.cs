﻿using MySql.Data.MySqlClient;
using Synthesis.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synthesis.Persistance
{
    public interface IUserDB
    {
        //retrieving all users from the database in a list of users
        List<User> GetUsers();

        //search through the database for users that have a specific email; result can be 1 or 0
        int NumberOfUsersWithSpecificName(string email);

        //create a new user with a new email and a password
        void CreateAccount(string email, string password, string role);

      

        //update a password for a specific email
        void ResetPassword(string email, string password);

        //searching for an id for a specific email
        int SearchForID(string email);

        string ReturnRoleOfUser(string email);

    }
}
