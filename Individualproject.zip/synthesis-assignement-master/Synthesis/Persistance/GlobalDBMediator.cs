﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaBazaar.Persistance
{
    class GlobalDBMediator
    {
        private MySqlConnection myDBConnection;

        public GlobalDBMediator()
        {
            string dbConnectionInfo =
                "server = studmysql01.fhict.local;" +
                "database = dbi477923;" +
                "uid = dbi477923;" +
                "password = secret;";

            this.myDBConnection = new MySqlConnection(dbConnectionInfo);
        }

        public MySqlConnection GetDBConnection()
        {
            return this.myDBConnection;
        }
    }
}
