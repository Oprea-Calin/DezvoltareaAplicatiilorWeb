﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synthesis.Persistance
{
    public class TournamentsDB : ITournamentsDB
    {

        public string DeleteTournament(int id)
        {
            try
            {
                MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
                MySqlCommand cmd = new MySqlCommand("DELETE FROM `tournamentss` WHERE `id` = '" + id + "';", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                return "Tournament deleted!";
            }catch(Exception e)
            {
                return e.Message.ToString();
            }
                
        }

        public string EditTournament(int id, string SportType, string Description, DateTime startDate, DateTime endDate, string MinimumPlayers, string MaximumPlayers, string Location, string TournamentSystem)
        {
            try
            {
                MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
                MySqlCommand cmd = new MySqlCommand("update tournamentss SET sport_type ='" + SportType + "', description= '" + Description + "', start_date ='" + startDate.Date.ToShortDateString() + "' , end_date= '" + endDate.Date.ToShortDateString() + "', min_Players= '" + MinimumPlayers + "', max_players= '" + MaximumPlayers + "', location= '" + Location + "', system= '" + TournamentSystem + "' WHERE id='" + id + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            { return e.Message.ToString(); }

            return "Tournament Edited!";
        }


        public string CreateTournament(string SportType, string Description, DateTime startDate, DateTime endDate, string MinimumPlayers, string MaximumPlayers, string Location, string TournamentSystem)
        {
            try
            {
                MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
                MySqlCommand cmd = new MySqlCommand("insert into tournamentss(sport_type, description, start_date, end_date, min_Players, max_players, location, system, registeredplayers)values('" + SportType + "','" + Description + "','" + startDate.Date.ToShortDateString() + "','" + endDate.Date.ToShortDateString() + "','" + MinimumPlayers + "','" + MaximumPlayers + "','" + Location + "','" + TournamentSystem + "','"+ 0 + "')", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch(Exception e)
            { return e.Message.ToString(); }

            return "Tournament Created!";
        }

        public DataSet DisplayAllUsers()
        {
            try
            {
                DataSet result = new DataSet();
                MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
                MySqlDataAdapter cmd = new MySqlDataAdapter("SELECT id, sport_type, description, start_date, end_date, min_Players, max_players, location, system, registeredplayers FROM tournamentss", conn);
                conn.Open();
                cmd.Fill(result, "tournamentss");
                conn.Close();
                return result;
            }catch
            {
                DataSet result = new DataSet();
                return result;
            }
        }
    }
}
