﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synthesis.Persistance
{
    public interface ITournamentsDB
    {
        string CreateTournament(string SportType, string Description, DateTime startDate, DateTime endDate, string MinimumPlayers, string MaximumPlayers, string Location, string TournamentSystem);
        DataSet DisplayAllUsers();
        string EditTournament(int id,string SportType, string Description, DateTime startDate, DateTime endDate, string MinimumPlayers, string MaximumPlayers, string Location, string TournamentSystem);
        string DeleteTournament(int id);


    }
}
