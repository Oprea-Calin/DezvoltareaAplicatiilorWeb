﻿using Synthesis.Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Synthesis
{
    public partial class AdminForm : Form
    {
        int id;
        bool editEmployeeInfo = false;
        AdminLogic adminLogic = new AdminLogic();
        public AdminForm(int id)
        {
            InitializeComponent();
            this.id = id;
            dgvTournaments.DataSource = adminLogic.ReturnAllUsers();
            dgvTournaments.DataMember = "tournamentss";
            cbSportType.SelectedIndex = 0;
            cbTournamentSystem.SelectedIndex = 0;

        }

        private void AdminForm_Load(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            if (editEmployeeInfo == false)
            {
                string message = adminLogic.CreateTournament(cbSportType.SelectedItem.ToString(), rtbDecription.Text, dtpStartDate.Value, dtpEndDate.Value, tbMinimumPlayers.Text, tbMaximumPlayers.Text, tbLocation.Text, cbTournamentSystem.SelectedItem.ToString());
                MessageBox.Show(message);
            }
            else
            {
                string message = adminLogic.EditTournament(Convert.ToInt32(lblIDSelectedRow.Text),cbSportType.SelectedItem.ToString(), rtbDecription.Text, dtpStartDate.Value, dtpEndDate.Value, tbMinimumPlayers.Text, tbMaximumPlayers.Text, tbLocation.Text, cbTournamentSystem.SelectedItem.ToString());
                MessageBox.Show(message);
            }
            cbSportType.SelectedItem = "";
            rtbDecription.Text = "";
            dtpStartDate.Value = DateTime.Now.Date;
            dtpEndDate.Value = DateTime.Now.Date;
            tbMinimumPlayers.Text = "";
            tbMaximumPlayers.Text = "";
            tbLocation.Text = "";
            cbTournamentSystem.SelectedItem = "";

            btnAddTournament.Text = "Add Tournament";
            editEmployeeInfo = false;
            lblIDSelectedRow.Text = "";

        }


        private void btnRefreshTable_Click(object sender, EventArgs e)
        {
            dgvTournaments.DataSource = adminLogic.ReturnAllUsers();
            dgvTournaments.DataMember = "tournamentss";
        }

        private void dgvTournaments_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int index = e.RowIndex;
            DataGridViewRow selectedRow = dgvTournaments.Rows[index];
            cbSportType.SelectedItem = selectedRow.Cells[1].Value.ToString();
            rtbDecription.Text = selectedRow.Cells[2].Value.ToString();
            dtpStartDate.Value = Convert.ToDateTime(selectedRow.Cells[3].Value);
            dtpEndDate.Value = Convert.ToDateTime(selectedRow.Cells[4].Value);
            tbMinimumPlayers.Text = selectedRow.Cells[5].Value.ToString();
            tbMaximumPlayers.Text = selectedRow.Cells[6].Value.ToString();
            tbLocation.Text = selectedRow.Cells[7].Value.ToString();
            cbTournamentSystem.SelectedItem = selectedRow.Cells[8].Value.ToString();

            btnAddTournament.Text = "Edit Tournament";
            editEmployeeInfo = true;
            lblIDSelectedRow.Text = selectedRow.Cells[0].Value.ToString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (btnAddTournament.Text == "Edit Tournament")
            {
                MessageBox.Show(adminLogic.DeleteTournament(Convert.ToInt32(lblIDSelectedRow.Text)));

                cbSportType.SelectedItem = "";
                rtbDecription.Text = "";
                dtpStartDate.Value = DateTime.Now.Date;
                dtpEndDate.Value = DateTime.Now.Date;
                tbMinimumPlayers.Text = "";
                tbMaximumPlayers.Text = "";
                tbLocation.Text = "";
                cbTournamentSystem.SelectedItem = "";

                btnAddTournament.Text = "Add Tournament";
                editEmployeeInfo = false;
                lblIDSelectedRow.Text = "";
            }
            else MessageBox.Show("Please select a tournament in order to delete it!");
        }

        private void dgvTournaments_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
