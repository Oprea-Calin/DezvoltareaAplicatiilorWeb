﻿using Synthesis.Models;
using Synthesis.Persistance;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synthesis.Business
{
    public class AdminLogic
    {

        TournamentsDB tournamentsDB = new TournamentsDB();

        public DataSet ReturnAllUsers()
        {
            return tournamentsDB.DisplayAllUsers();
        }
        public string DeleteTournament(int id)
        {
            return tournamentsDB.DeleteTournament(id);
        }

        public string EditTournament(int id,string SportType, string Description, DateTime startDate, DateTime endDate, string MinimumPlayers, string MaximumPlayers, string Location, string TournamentSystem)
        {
            int min, max;
            bool isNumericMin = int.TryParse(MinimumPlayers, out min);
            bool isNumericMax = int.TryParse(MaximumPlayers, out max);

            if (SportType == null) return "SportType missing!";
            else if (Description == "") return "Description missing!";
            else if (startDate > endDate) return "End date cannot be before start date.";
            else if (startDate.Date < DateTime.Now.AddDays(14).Date) return "An event must be announced 14 days before starting!";
            else if (isNumericMax == false) return "Maximum players must be a number!";
            else if (isNumericMin == false) return "Minimum players must be a number!";
            else if (TournamentSystem == "") return "Tournament System missing!";
            else if (Location == "") return "Location missing!";
            else if (min > max) return "Minimum players must be less or equal to the maximum players value.";


            return tournamentsDB.EditTournament(id,SportType, Description, startDate, endDate, MinimumPlayers, MaximumPlayers, Location, TournamentSystem);
        }

        public string CreateTournament(string SportType, string Description, DateTime startDate, DateTime endDate, string MinimumPlayers, string MaximumPlayers, string Location, string TournamentSystem)
        {
            int min,max;
            bool isNumericMin = int.TryParse(MinimumPlayers, out min);
            bool isNumericMax = int.TryParse(MaximumPlayers, out max);

            if (SportType == null) return "SportType missing!";
            else if (Description == "") return "Description missing!";
            else if (startDate > endDate) return "End date cannot be before start date.";
            else if (startDate.Date < DateTime.Now.AddDays(14).Date) return "An event must be announced 14 days before starting!";
            else if (isNumericMax == false) return "Maximum players must be a number!";
            else if (isNumericMin == false) return "Minimum players must be a number!";
            else if (TournamentSystem == "") return "Tournament System missing!";
            else if (Location == "") return "Location missing!";
            else if (min > max) return "Minimum players must be less or equal to the maximum players value.";


            return tournamentsDB.CreateTournament(SportType, Description, startDate, endDate, MinimumPlayers, MaximumPlayers, Location, TournamentSystem);   
        }
        
    }
}
