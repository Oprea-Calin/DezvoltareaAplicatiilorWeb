﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synthesis.Models
{
    public class User
    {
        //we remember only the id , email and password for a user
        int id;
        string email, password,type;
        public User(int id, string username, string password)
        {
            this.id = id;
            this.email = username;
            this.password = password;
        }
        public User(int id, string username, string password,string type)
        {
            this.id = id;
            this.email = username;
            this.password = password;
            this.type = type;
        }
        public User(string username, string password)
        {
            this.email = username;
            this.password = password;
        }
        public User()
        {

        }
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string Password
        {
            get { return password; }
            set { password = value; }
        }
    }
}
