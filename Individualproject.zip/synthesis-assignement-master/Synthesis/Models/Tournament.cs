﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synthesis.Models
{
    public class Tournament
    {
        string sportType, description, location, system;
        int minPlayers, maxPlayers, registeredPlayers;
        DateTime startDate, endDate;

        public int RegisteredPlayers{ get { return registeredPlayers; } }
        public int MaxPlayers { get { return maxPlayers; } }
        public Tournament(string sportType, string description, int minPlayers, int maxPlayers, string location, string system, DateTime startDate, DateTime endDate,int registeredPlayers)
        {
            this.registeredPlayers = registeredPlayers;
            this.sportType = sportType;
            this.description = description;
            this.minPlayers = minPlayers;
            this.maxPlayers = maxPlayers;
            this.location = location;
            this.system = system;
            this.startDate = startDate;
            this.endDate = endDate;
        }

        public string ReturnInfo()
        {
            string a = "Tournament details: " + description + ". Location " + location + ". Sport type: " + sportType + " Minimum players: " + minPlayers + ". Maximum players: " + maxPlayers + " Registered players: "+ registeredPlayers +". Start date: " + startDate.ToShortDateString() + ". End Date: " + endDate.ToShortDateString();
            return a;
        }
    }
}
