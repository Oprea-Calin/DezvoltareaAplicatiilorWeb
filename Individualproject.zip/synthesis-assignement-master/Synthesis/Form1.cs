﻿using Synthesis.Business;
using Synthesis.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Synthesis
{
    public partial class Form1 : Form
    {
        LoginLogic loginLogic = new LoginLogic();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            List<User> users = loginLogic.AddUsersFromList();

            if (tbEmail.Text != "")
            {
                if (tbPassword.Text != "")
                {
                    if (loginLogic.IsValidEmail(tbEmail.Text))
                    {
                        bool ok = loginLogic.VerifyCredentials(tbEmail.Text, tbPassword.Text);
                        if (ok)
                        {

                            int id = loginLogic.ReturnIDOfUser(tbEmail.Text);
                            string role = loginLogic.ReturnRoleOfUser(tbEmail.Text);

                            if (role == "Admin")
                            {
                                this.Hide();
                                AdminForm mainFrom = new AdminForm(id);
                                mainFrom.Closed += (s, args) => this.Close();
                                mainFrom.Show();
                            }
                            else MessageBox.Show("Login has failed!");
                            //we pass the id of the logged user for future use

                           /* */
                        }
                        else MessageBox.Show("Login failed!");
                    }
                    else MessageBox.Show("Please insert a valid mail!");
                }
                else MessageBox.Show("Please fill in password!");
            }
            else MessageBox.Show("Please fill in username!");
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            this.Hide();
            CreateAccountForm createAccount = new CreateAccountForm();
            createAccount.Closed += (s, args) => this.Close();
            createAccount.Show();
        }
    }
}
