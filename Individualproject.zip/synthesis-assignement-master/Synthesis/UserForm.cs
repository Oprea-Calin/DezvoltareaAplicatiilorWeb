﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Synthesis
{
    public partial class UserForm : Form
    {
        int id;
        public UserForm(int id)
        {
            InitializeComponent();
            this.id = id;
        }

        private void UserForm_Load(object sender, EventArgs e)
        {

        }
    }
}
