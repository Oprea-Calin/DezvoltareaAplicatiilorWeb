﻿
namespace Synthesis
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.lblIDSelectedRow = new System.Windows.Forms.Label();
            this.btnRefreshTable = new System.Windows.Forms.Button();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.btnAddTournament = new System.Windows.Forms.Button();
            this.dgvTournaments = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.cbTournamentSystem = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbLocation = new System.Windows.Forms.TextBox();
            this.tbMaximumPlayers = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbMinimumPlayers = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rtbDecription = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbSportType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTournaments)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1093, 690);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.lblIDSelectedRow);
            this.tabPage1.Controls.Add(this.btnRefreshTable);
            this.tabPage1.Controls.Add(this.dtpEndDate);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.dtpStartDate);
            this.tabPage1.Controls.Add(this.btnAddTournament);
            this.tabPage1.Controls.Add(this.dgvTournaments);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.cbTournamentSystem);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.tbLocation);
            this.tabPage1.Controls.Add(this.tbMaximumPlayers);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.tbMinimumPlayers);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.rtbDecription);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.cbSportType);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1085, 661);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Create Tournament";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(923, 15);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 65);
            this.button1.TabIndex = 22;
            this.button1.Text = "Delete Selected Tournament";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // lblIDSelectedRow
            // 
            this.lblIDSelectedRow.AutoSize = true;
            this.lblIDSelectedRow.Location = new System.Drawing.Point(549, 15);
            this.lblIDSelectedRow.Name = "lblIDSelectedRow";
            this.lblIDSelectedRow.Size = new System.Drawing.Size(0, 17);
            this.lblIDSelectedRow.TabIndex = 21;
            this.lblIDSelectedRow.Visible = false;
            // 
            // btnRefreshTable
            // 
            this.btnRefreshTable.Location = new System.Drawing.Point(377, 15);
            this.btnRefreshTable.Name = "btnRefreshTable";
            this.btnRefreshTable.Size = new System.Drawing.Size(142, 65);
            this.btnRefreshTable.TabIndex = 20;
            this.btnRefreshTable.Text = "Refresh Tournaments";
            this.btnRefreshTable.UseVisualStyleBackColor = true;
            this.btnRefreshTable.Click += new System.EventHandler(this.btnRefreshTable_Click);
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.Location = new System.Drawing.Point(30, 353);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(245, 22);
            this.dtpEndDate.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(27, 318);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 17);
            this.label9.TabIndex = 18;
            this.label9.Text = "End Date";
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Location = new System.Drawing.Point(30, 279);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(245, 22);
            this.dtpStartDate.TabIndex = 17;
            // 
            // btnAddTournament
            // 
            this.btnAddTournament.Location = new System.Drawing.Point(98, 595);
            this.btnAddTournament.Name = "btnAddTournament";
            this.btnAddTournament.Size = new System.Drawing.Size(142, 39);
            this.btnAddTournament.TabIndex = 16;
            this.btnAddTournament.Text = "Add Tournament";
            this.btnAddTournament.UseVisualStyleBackColor = true;
            this.btnAddTournament.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgvTournaments
            // 
            this.dgvTournaments.AllowUserToDeleteRows = false;
            this.dgvTournaments.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTournaments.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvTournaments.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvTournaments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTournaments.Location = new System.Drawing.Point(377, 98);
            this.dgvTournaments.Name = "dgvTournaments";
            this.dgvTournaments.ReadOnly = true;
            this.dgvTournaments.RowHeadersWidth = 51;
            this.dgvTournaments.RowTemplate.Height = 24;
            this.dgvTournaments.Size = new System.Drawing.Size(688, 536);
            this.dgvTournaments.TabIndex = 15;
            this.dgvTournaments.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTournaments_CellContentClick);
            this.dgvTournaments.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTournaments_CellDoubleClick);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 537);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(135, 17);
            this.label8.TabIndex = 14;
            this.label8.Text = "Tournament System";
            // 
            // cbTournamentSystem
            // 
            this.cbTournamentSystem.AutoCompleteCustomSource.AddRange(new string[] {
            "Round-Robin",
            "Double Round-Robin"});
            this.cbTournamentSystem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTournamentSystem.FormattingEnabled = true;
            this.cbTournamentSystem.Items.AddRange(new object[] {
            "Round-Robin",
            "Double Round-Robin"});
            this.cbTournamentSystem.Location = new System.Drawing.Point(30, 557);
            this.cbTournamentSystem.Name = "cbTournamentSystem";
            this.cbTournamentSystem.Size = new System.Drawing.Size(284, 24);
            this.cbTournamentSystem.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(27, 459);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 17);
            this.label7.TabIndex = 12;
            this.label7.Text = "Location";
            // 
            // tbLocation
            // 
            this.tbLocation.Location = new System.Drawing.Point(30, 489);
            this.tbLocation.Name = "tbLocation";
            this.tbLocation.Size = new System.Drawing.Size(284, 22);
            this.tbLocation.TabIndex = 11;
            // 
            // tbMaximumPlayers
            // 
            this.tbMaximumPlayers.Location = new System.Drawing.Point(203, 423);
            this.tbMaximumPlayers.Name = "tbMaximumPlayers";
            this.tbMaximumPlayers.Size = new System.Drawing.Size(111, 22);
            this.tbMaximumPlayers.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(200, 389);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 17);
            this.label6.TabIndex = 9;
            this.label6.Text = "Maximum Players";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 389);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(114, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Minimum Players";
            // 
            // tbMinimumPlayers
            // 
            this.tbMinimumPlayers.Location = new System.Drawing.Point(30, 423);
            this.tbMinimumPlayers.Name = "tbMinimumPlayers";
            this.tbMinimumPlayers.Size = new System.Drawing.Size(111, 22);
            this.tbMinimumPlayers.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Start Date";
            // 
            // rtbDecription
            // 
            this.rtbDecription.Location = new System.Drawing.Point(30, 155);
            this.rtbDecription.Name = "rtbDecription";
            this.rtbDecription.Size = new System.Drawing.Size(284, 80);
            this.rtbDecription.TabIndex = 5;
            this.rtbDecription.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Description";
            // 
            // cbSportType
            // 
            this.cbSportType.AutoCompleteCustomSource.AddRange(new string[] {
            "Badminton"});
            this.cbSportType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSportType.FormattingEnabled = true;
            this.cbSportType.Items.AddRange(new object[] {
            "Badminton"});
            this.cbSportType.Location = new System.Drawing.Point(30, 98);
            this.cbSportType.Name = "cbSportType";
            this.cbSportType.Size = new System.Drawing.Size(284, 24);
            this.cbSportType.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Sport Type";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 35);
            this.label1.TabIndex = 1;
            this.label1.Text = "Add new tournament";
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1085, 661);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1098, 673);
            this.Controls.Add(this.tabControl1);
            this.Name = "AdminForm";
            this.Text = "AdminForm";
            this.Load += new System.EventHandler(this.AdminForm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTournaments)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox cbSportType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox rtbDecription;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbMaximumPlayers;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbMinimumPlayers;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbTournamentSystem;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbLocation;
        private System.Windows.Forms.DataGridView dgvTournaments;
        private System.Windows.Forms.Button btnAddTournament;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnRefreshTable;
        private System.Windows.Forms.Label lblIDSelectedRow;
        private System.Windows.Forms.Button button1;
    }
}