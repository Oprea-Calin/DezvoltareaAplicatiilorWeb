﻿using Synthesis.Business;
using Synthesis.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Synthesis
{
    public partial class CreateAccountForm : Form
    {
        LoginLogic loginLogic = new LoginLogic();
        public CreateAccountForm()
        {
            InitializeComponent();
        }

        private void btnCreateAccount_Click(object sender, EventArgs e)
        {
            List<User> users = loginLogic.AddUsersFromList();

            if (tbMail.Text != "")
            {
                if (loginLogic.IsValidEmail(tbMail.Text) == true)
                {
                    if (tbPassword.Text != "")
                    {
                        if (tbPassword.Text == tbRepeatPassword.Text)
                        {
                            if (loginLogic.UserNameCheck(tbMail.Text) == false)
                            {
                                loginLogic.CreateAccount(tbMail.Text, tbPassword.Text,"Admin");
                                int id = loginLogic.SearchForId(tbMail.Text);
                                this.Hide();
                                Form1 form1 = new Form1();
                                form1.Closed += (s, args) => this.Close();
                                MessageBox.Show("Account created successfully!");
                                form1.Show();
                            }
                            else MessageBox.Show("Email already exists!");
                        }
                        else MessageBox.Show("Passwords don't match!");
                    }
                    else MessageBox.Show("Please fill in a password!");
                }
                else MessageBox.Show("Please fill in a valid email!");
            }
            else MessageBox.Show("Please fill in email!");
        }
    }
}
