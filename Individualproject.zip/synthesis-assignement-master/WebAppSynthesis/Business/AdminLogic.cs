﻿using Synthesis.Models;
using Synthesis.Persistance;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using WebAppSynthesis.Persistance;

namespace WebAppSynthesis.Business
{
    public class AdminLogic
    {
        TournamentsDAL tournamentsDAL = new TournamentsDAL();
        UserDAL userDAL = new UserDAL();
        public List<Tournament> DisplayAllTournaments() 
        {
            List<Tournament> tournaments = new List<Tournament>();
            tournaments = tournamentsDAL.DisplayAllTournaments();
            return tournaments;
        }
        public string RegisterPlayer(int idPlayer, int idTournament)
        {
            bool ok = tournamentsDAL.CheckisPlayerIsRegistered(idPlayer, idTournament);
            string result;
            if (ok == true)
                result = tournamentsDAL.RegisterPlayerToTournament(idTournament, idPlayer);
            else result = "";
            return result;
        }
        
        public int GetUserID(string email)
        {
            return userDAL.SearchForID(email);
        }

        public int GetTournamentIDByIndice(int ind)
        {
            int a = tournamentsDAL.GetTournamentIDByIndice(ind);
            return a;
        }

    }
}
