﻿using Synthesis.Models;
using Synthesis.Persistance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppSynthesis.Business
{
    public class LoginLogic
    {
        UserDAL userDB = new UserDAL();

        /* //a list of users that in the future will be implemented in the database class(CommunityDB)
         List<User> users = new List<User>();
         public User AddUsers
         {
             set { users.Add(value); }
         }
         public List<User> Users
         {
             get { return users; }
         }
         public string ReturnInfo(int i)
         {
             return $"{users[i].Email} has id: {users[i].ID} and password: {users[i].Password}";
         }
        */
        //verification of an email if it respects the syntax of an email adress
        public bool IsValidEmail(string eMail)
        {
            bool Result = false;
            try
            {
                var eMailValidator = new System.Net.Mail.MailAddress(eMail);

                Result = (eMail.LastIndexOf(".") > eMail.LastIndexOf("@"));
            }
            catch
            {
                Result = false;
            };
            return Result;
        }

        //we check if an email is in the database
        public bool IsInDatabase(string email)
        {

            int TotalRows = userDB.NumberOfUsersWithSpecificName(email);
            if (TotalRows > 0)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
        public List<User> AddUsersFromList()
        {
            List<User> users = new List<User>();
            users = userDB.GetUsers();
            return users;
        }

        //we check is an email is already in the database for new users
        public bool UserNameCheck(string email)
        {
            int TotalRows = userDB.NumberOfUsersWithSpecificName(email);
            if (TotalRows > 0)
            {

                return true;
            }
            else
            {

                return false;
            }
        }

        //we check is specific credentials are in the database
        public bool VerifyCredentials(string email, string password)
        {
            List<User> users = new List<User>();
            users = userDB.GetUsers();
            bool ok = false;
            for (int i = 0; i < users.Count() && ok == false; i++)
            {
                if (email == users[i].Email)
                    if (password == users[i].Password) return true;
            }
            return false;
        }

        public int ReturnIDOfUser(string email)
        {
            int id = Convert.ToInt32(userDB.SearchForID(email));
            if (id >= 0)
                return id;
            else return -1;
        }

        public string ReturnRoleOfUser(string email)
        {
            string role = userDB.ReturnRoleOfUser(email);
            if (role != "") return role;
            return "error";
        }

        public void CreateAccount(string email, string password, string role)
        {
            userDB.CreateAccount(email, password, role);
        }

        public int SearchForId(string email)
        {
            return userDB.SearchForID(email);
        }
    }
}
