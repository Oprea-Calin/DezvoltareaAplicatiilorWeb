﻿using Synthesis.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Synthesis.Persistance
{
    public interface ITournamentsDAL
    {
        List<Tournament> DisplayAllTournaments();
        string RegisterPlayerToTournament(int idTournament, int idPlayer);
        int GetRegisteredPlayersByTournamentID(int id);
        int IsAPlayerRegisteredToTournament(int playerID, int tournamentID);

        bool CheckisPlayerIsRegistered(int idPlayer, int idTournament);

    }
}
