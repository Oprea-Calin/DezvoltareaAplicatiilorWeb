﻿using MySql.Data.MySqlClient;
using Synthesis.Models;
using Synthesis.Persistance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppSynthesis.Persistance
{
    public class TournamentsDAL : ITournamentsDAL
    {
        public bool CheckisPlayerIsRegistered(int idPlayer, int idTournament)
        {
            int result=0;
            try
            {
                MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
                MySqlCommand cmd = new MySqlCommand("SELECT COUNT(*) FROM tournaments_playerss WHERE tournamentID=@id  AND playerID=@playerID", conn);
                cmd.Parameters.AddWithValue("@id", idTournament);
                cmd.Parameters.AddWithValue("@playerID", idPlayer);

                conn.Open();
                result = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();
                if (result == 0) return true;
                else return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public int GetTournamentIDByIndice(int ind)
        {
            
            int result=-1;
            try
            {
                MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
                MySqlCommand cmd = new MySqlCommand("SELECT id FROM tournamentss ORDER BY id LIMIT 1 OFFSET @ros", conn);
                cmd.Parameters.AddWithValue("@ros", ind);
                conn.Open();
                result = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();
                return result;
            }
            catch (Exception e)
            {
                return result;
            }



           
        }

      
        public string RegisterPlayerToTournament(int idTournament, int idPlayer)
        {
            int registeredPlayers = GetRegisteredPlayersByTournamentID(idPlayer);
            if (registeredPlayers != -1)
            {
                bool ok1 = false, ok2 = false;
                registeredPlayers++;
                try
                {
                    MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
                    MySqlCommand cmd = new MySqlCommand("update tournamentss SET registeredplayers=@registeredPlayers WHERE id=@idTournament", conn);
                    cmd.Parameters.AddWithValue("@registeredPlayers", registeredPlayers);
                    cmd.Parameters.AddWithValue("@idTournament", idTournament);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    ok1 = true;
                }
                catch (Exception e)
                { e.Message.ToString(); }


                try
                {
                    MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
                    MySqlCommand cmd = new MySqlCommand("insert into tournaments_playerss(tournamentID, playerID) values(@tournamentID,@playerID)", conn);
                    cmd.Parameters.AddWithValue("@tournamentID", idTournament);
                    cmd.Parameters.AddWithValue("@playerID", idPlayer);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    ok2 = true;
                    
                }
                catch(Exception e)
                {
                    e.Message.ToString();
                }


                if (ok1 == true && ok2 == true) return "Player registered!";
                else return "promblen";
            }




            return "Promblen";

        }
        public int GetRegisteredPlayersByTournamentID(int id)
        {
            int result = -1;
            try
            {
                MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
                MySqlCommand cmd = new MySqlCommand("SELECT registeredplayers FROM tournamentss WHERE id='" + id + "'", conn);
                conn.Open();
                result = Convert.ToInt32(cmd.ExecuteScalar());   
                conn.Close();
                return result;
            }
            catch (Exception e)
            {
                return result;
            }
        }

        public List<Tournament> DisplayAllTournaments()
        {
            List<Tournament> tournaments = new List<Tournament>();
            try
            {
                MySqlDataReader myReader;
                MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
                MySqlCommand cmd = new MySqlCommand("SELECT sport_type, description,min_Players, max_players,location,system, start_date, end_date, registeredplayers FROM tournamentss", conn);
                conn.Open();
                myReader = cmd.ExecuteReader();
                int i = 0;
                while (myReader.Read())
                {
                    tournaments.Add(new Tournament(myReader[i].ToString(),myReader[i+1].ToString(),Convert.ToInt32(myReader[i+2]),Convert.ToInt32(myReader[i+3]), myReader[i+4].ToString(), myReader[i+5].ToString(),Convert.ToDateTime(myReader[i+6]),Convert.ToDateTime(myReader[i+7]), Convert.ToInt32(myReader[i+8])));
                }
                conn.Close();
                return tournaments;
            }
            catch(Exception e)
            {
                return tournaments;
            }
        }

        public int IsAPlayerRegisteredToTournament(int playerID, int tournamentID)
        {
            int result = -1;
            try
            {
                MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
                MySqlCommand cmd = new MySqlCommand("SELECT COUNT(*) FROM tournaments_playerss WHERE playerID ='"+ playerID + "' AND tournamentID='" + tournamentID + "'" , conn);
                conn.Open();
                result = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();
                return result;
            }
            catch (Exception e)
            {
                return result;
            }
        }


    }
}
