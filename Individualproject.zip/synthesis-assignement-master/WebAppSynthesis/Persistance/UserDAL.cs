﻿using MySql.Data.MySqlClient;
using Synthesis.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Synthesis.Persistance
{
    public class UserDAL : IUserDB
    {
        //retrieving all users from the database in a list of users
        public List<User> GetUsers()
        {
            List<User> Users = new List<User>();
            MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
            MySqlCommand cmd = new MySqlCommand("select * from userss;", conn);
            conn.Open();
            MySqlDataReader myReader = cmd.ExecuteReader();
            while (myReader.Read())
            {
                User user = new User(Convert.ToInt32(myReader[0]), myReader[1].ToString(), myReader[2].ToString(), myReader[3].ToString());
                Users.Add(user);
            }
            conn.Close();
            return Users;
        }

        //search through the database for users that have a specific email; result can be 1 or 0
        public int NumberOfUsersWithSpecificName(string email)
        {
            MySqlConnection con = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
            MySqlCommand cmd = new MySqlCommand("Select count(*) from userss where Email= @alias", con);
            cmd.Parameters.AddWithValue("@alias", email);
            con.Open();
            int TotalRows = 0;
            TotalRows = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            return TotalRows;
        }

        //create a new user with a new email and a password
        public void CreateAccount(string email, string password, string role)
        {
            MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
            MySqlCommand cmd = new MySqlCommand("insert into userss(Email, Password, role)values('" + email + "','" + password + "','" + role + "')", conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        


        //update a password for a specific email
        public void ResetPassword(string email, string password)
        {
            MySqlConnection conn = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
            MySqlCommand cmd = new MySqlCommand("UPDATE `dbi477923`.`userss`SET`Password` = '" + password + "' WHERE `Email` = '" + email + "'; ", conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        //searching for an id for a specific email
        public int SearchForID(string email)
        {
            MySqlConnection con = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
            MySqlCommand cmd = new MySqlCommand("Select id from userss where Email= @alias", con);
            cmd.Parameters.AddWithValue("@alias", email);
            con.Open();
            int id = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            return id;
        }

        public string ReturnRoleOfUser(string email)
        {
            MySqlConnection con = new MySqlConnection("server=studmysql01.fhict.local;database=dbi477923;uid=dbi477923;password=secret;");
            MySqlCommand cmd = new MySqlCommand("Select role from userss where Email= @alias", con);
            cmd.Parameters.AddWithValue("@alias", email);
            con.Open();
            string role = Convert.ToString(cmd.ExecuteScalar());
            con.Close();
            return role;
        }
    }
}
