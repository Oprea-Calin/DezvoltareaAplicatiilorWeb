using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Synthesis.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using WebAppSynthesis.Business;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;

namespace WebAppSynthesis.Pages
{
    [Authorize]
    public class HomepageLoggedModel : PageModel
    {
        public List<Tournament> TournamentList = new List<Tournament>();
        AdminLogic adminLogic = new AdminLogic();
        
        

        [BindProperty]
        public int ID { get; set; }

        public string Message{ get; set; }
        public void OnGet()
        {
            TournamentList = adminLogic.DisplayAllTournaments();
        }
        public void OnPostRegister(int id)
        {
            ID = id;
            // return RedirectToPage();
            var Player = Request.Cookies["currentUser"];
            int playerID = adminLogic.GetUserID(Player.ToString());
            int idbun = adminLogic.GetTournamentIDByIndice(id);


            string a =adminLogic.RegisterPlayer(playerID, idbun);
            //string b = a;
            
        }
        


    }
}
