using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Synthesis.Models;
using WebAppSynthesis.Business;

namespace WebAppSynthesis.Pages
{
    public class LoginPageModel : PageModel
    {
        [BindProperty]
        public User UserInfo { get; set; }
        LoginLogic loginLogic = new LoginLogic();
         
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {

                if (!string.IsNullOrEmpty(UserInfo.Email) && !string.IsNullOrEmpty(UserInfo.Password))
                {
                    if (loginLogic.VerifyCredentials(UserInfo.Email, UserInfo.Password))
                    {

                        CookieOptions cookie = new CookieOptions();
                        Response.Cookies.Append("currentUser", UserInfo.Email);

                        List<Claim> claims = new List<Claim>();
                        claims.Add(new Claim(ClaimTypes.Name, UserInfo.Email));
                        claims.Add(new Claim("id", "1"));

                        var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                        HttpContext.SignInAsync(new ClaimsPrincipal(claimsIdentity));



                        return RedirectToPage("HomepageLogged");
                    }



                }
                else
                {
                    return RedirectToPage("Index");
                }
            }
            return null;
        }
    }
}
