﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using Synthesis.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAppSynthesis.Business;

namespace WebAppSynthesis.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        
        public List<Tournament> TournamentList = new List<Tournament>();
        AdminLogic adminLogic = new AdminLogic();
        int id;
        [BindProperty]
        public int ID { get { return id; } set { id = value; } }
        public void OnGet()
        {
            TournamentList = adminLogic.DisplayAllTournaments();
        }
        public IActionResult OnPost()
        {
            return Content(id.ToString());
        }
    }
}
