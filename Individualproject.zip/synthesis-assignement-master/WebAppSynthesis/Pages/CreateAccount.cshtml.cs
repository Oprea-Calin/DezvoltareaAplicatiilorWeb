using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Synthesis.Models;
using WebAppSynthesis.Business;
using System.Windows;

namespace WebAppSynthesis.Pages
{
    public class CreateAccountModel : PageModel
    {
        [BindProperty]
        public User UserInfo { get; set; }
        LoginLogic loginLogic = new LoginLogic();
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {

                if (!string.IsNullOrEmpty(UserInfo.Email) && !string.IsNullOrEmpty(UserInfo.Password))
                {
                    if (loginLogic.IsInDatabase(UserInfo.Email) == false)
                    {
                        if (loginLogic.IsValidEmail(UserInfo.Email) == true)
                        {
                            loginLogic.CreateAccount(UserInfo.Email, UserInfo.Password, "User");
                            return RedirectToPage("LoginPage");
                        }
                    }
                }
                


            }
            return null;
        }
    }
}
